CREATE DATABASE ficha7;

USE ficha7;

INSERT INTO ficha7.persons(firstname, lastname, profession, age)
VALUES ('Joshua','Armand','josh@example.com', 37);

SELECT * FROM ficha7.persons;

ALTER USER 'root'@'localhost' IDENTIFIED BY '';
ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '';

